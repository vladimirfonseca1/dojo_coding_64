-- 1) Consulte todos os funcionários


-- 2) Consulte somente o nome e sobrenome de todos os funcionários


-- 3) Consulte somente o nome e sobrenome dos funcionários ordenado pelo nome


-- 4) Consulte todos as colunas dos funcionários ordenado pelo salário do menor para maior


-- 5) Retorne somente os 5 funcionários


-- 6) Retorne somente os 5 funcionários com maior salário


-- 7) Consulte funcionários que recebem acima ou igual a 15 mil reais


-- 8) Consulte somente o nome, sobrenome e salario do funcionário que possui id 177


-- 9) Consulte os funcionários que são do departamento de "Vendas" e possuem salário acima de 10 mil


-- 10) Consulte os funcionários que são do departamento "Financeiro" ordenado pelo nome


-- 11) Consulte os funcionários que recebem entre 5 mil e 10 mil


-- 12) Consulte os funcionários do departamento "TI" que recebem entre 8 mil e 10 mil


-- 13) Consulte quantos funcionários existem na empresa


-- 14) Consulte a média salárial da empresa


-- 15) Consulte a média salarial agrupada por departamentos


-- 16) Consulte a quantidade de funcionários por departamentos


-- 17) Atualize o salário do funcionário com id 25 para 3 mil


-- 18) Atualize o salário do funcionário chamado Antonio para 2 mil


-- 19) Atualize em 10% o salário dos funcionários que recebem entre 5000 e 10000 e são do departamento "Marketing"


-- 20) Atualize em 5% o salário dos funcionários que recebem acima de 15000 e NÃO são do departamento "TI"

